@include('includes.menu')
<h1>Главная страница</h1>
