<ul>
    <li>
        <a href="{{ route('home') }}">{{ __('Главная') }}</a>
    </li>
    <li>
        <a href="{{ route('about') }}">{{ __('О нас') }}</a>
    </li>
</ul>

